  // user interface logic
  $(document).ready(function() {
    $("#getTreatment").submit(function(event) {
        event.preventDefault();
        var text = $("input#text").val();
        var words=text.split(" ");
        if (words[5]=== 'Gray_Leaf_Spot'){
            $('.Corn_gray_leaf_spot').show();
        }
        else if(words[5]==='Corn_Common_Rust'){
            $('.Corn_common_rust').show();
        }
        else if(words[5]==='Corn_Blight'){
            $('.Corn_northern_leaf_blight').show();
        }
        else if(words[5]=== 'Corn_Healthy'){
            $('.healthy').show();
        }
      });
    
      
  }); 
  